# Java script 
## Day 4 task4 
## Memory Game

## Go live
- *Home.html* in the pages folder

## The purpose
### In this project:
- You think you have a good memory?
let's check

Note: there are sounds in the game

https://user-images.githubusercontent.com/61587804/204105285-ecd0366e-15a4-41a6-94a7-595ebcb71cbc.mp4

